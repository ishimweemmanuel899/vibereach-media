
document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Thanks for reaching out! We'll vibe with you soon. 🎉");
  this.reset(); // Clears the form
});
